
# Easy AI Task: Face Detection

## Description
A simple real-time face detection project using OpenCV's Haar Cascade classifier.

## How to Run
1. Install dependencies:
   ```bash
   pip install opencv-python
   ```
2. Run the script:
   ```bash
   python face_detection.py
   ```

## Output
- Opens the webcam feed.
- Draws a green rectangle around detected faces.
- Press 'q' to quit.
